package ba.etf.rma26.projekat.data.repositories

object UradjeniKvizoviRepository {
    private val uradjeniKvizovi = mutableSetOf<Int>()

    suspend fun oznaciUradjen(idKviza: Int) {
        uradjeniKvizovi.add(idKviza)
    }

    suspend fun jeUradjen(idKviza: Int): Boolean {
        return idKviza in uradjeniKvizovi
    }

    suspend fun getUradjeni(): Set<Int> {
        return uradjeniKvizovi.toSet()
    }
}